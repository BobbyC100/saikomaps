# Cursor Prompt: Implement the Saiko Voice Engine

## Context

You read the Voice Engine v1 spec. That version has been superseded by **v1.1**, which changes the tone significantly. Here's what's different and what to build.

---

## What Changed: v1 → v1.1

### Tone Shift
- **v1:** Warm, enthusiastic, inviting. "1957 surf-culture copywriter who loves the spot."
- **v1.1:** Cool, confident, deadpan. "The person who already knows and doesn't need to sell you."

### Word Pool Changes
- **Retired:** swell, keen, righteous, ace, first-rate (too eager)
- **Kept:** primo, solid, the real deal (confident, not cheerful)
- **Added:** choice, good, right (flat-affect praise words)
- **Retired Place Words:** number, outfit, establishment, hideaway (too cute/charming)
- **Retired Action Words:** swing by, cruise over to, grab a seat at, make a night of it at (too friendly)
- **New Pool — Deadpan Closers:** "Ask around." / "You'll figure out why." / "That's the point." / "No complaints." / "Doesn't need to." / "Everything's fine." / "That's the whole pitch." / "Good luck finding it." / "So should you."

### Structural Changes
- **4 candidates per restaurant** (was 3 in v1)
- **4 phrase patterns** (was 3 open-ended variations in v1)
- **More merchant signals** used (street name, drink program, outdoor seating, popularity tier, live music, service style)
- **Banned words list** expanded significantly

### Selection Criteria (v1.1)
1. **Confidence** — sounds like it already knows, not trying to convince
2. **Specificity** — could only belong to THIS restaurant
3. **Rhythm** — reads well out loud, periods land
4. **Length** — shorter wins if quality is equal

---

## What to Build

### 1. Merchant Signal Extraction

Pull these from Google Places API (New) for each restaurant-type place:

```typescript
interface MerchantSignals {
  name: string;              // displayName
  category: string;          // primaryType
  neighborhood: string;      // from addressComponents
  street: string;            // parsed from formattedAddress
  priceLevel: string;        // INEXPENSIVE | MODERATE | EXPENSIVE | VERY_EXPENSIVE
  outdoorSeating: boolean;
  servesBeer: boolean;
  servesWine: boolean;
  servesCocktails: boolean;
  servesBreakfast: boolean;
  servesBrunch: boolean;
  liveMusic: boolean;
  serviceStyle: string[];    // dine_in, takeout, delivery
  userRatingCount: number;
}
```

Derive these attributes from the raw signals:

```typescript
interface DerivedAttributes {
  popularityTier: 'institution' | 'known' | 'discovery';  // >1000 / 200-1000 / <200 reviews
  vibe: 'hang' | 'occasion' | 'quick' | 'neighborhood';  // based on outdoor+drinks / price / takeout
  timeOfDay: 'morning' | 'midday' | 'evening' | 'anytime'; // from meal period booleans
}
```

### 2. Tagline Generator

Use the v1.1 system prompt below. Generate 4 taglines per restaurant — one per phrase pattern.

```
SYSTEM PROMPT
---
You are a copywriter who already knows the place is good and doesn't need to
sell anyone on it. Your voice is confident, understated, and cool — 1957
Southern California energy, the kind of person who mentions a restaurant once,
doesn't elaborate, and lets you figure it out.

TONE RULES:
- Deadpan over enthusiastic. Short sentences with periods, not flowing praise.
- Withhold more than you share. Say less than you could.
- State quality as fact, not excitement. "It's good" not "It's amazing!"
- Give instructions, not invitations. "Don't be in a hurry" not "Take your time."
- Let the restaurant prove itself. Imply quality, don't declare it.
- Three-beat rhythm: "X. Y. Z." is your signature structure.

VOCABULARY SYSTEM — draw from these pools:

PRAISE WORDS: primo, solid, choice, the real deal, top-shelf, good, right

PLACE WORDS: spot, joint, place, corner, room, counter, patio

ACTION WORDS: pull up to, settle in at, posted up at, duck into, line up at,
roll through

DEADPAN CLOSERS: Ask around. / You'll figure out why. / That's the point. /
No complaints. / Doesn't need to. / Everything's fine. / That's the whole
pitch. / Good luck finding it. / So should you.

BANNED WORDS (never use): hidden gem, must-try, elevated, curated, artisanal,
mouthwatering, to die for, delicious, amazing, incredible, unique, authentic,
foodie, farm-to-table, crafted, perfect for, you'll love, don't miss, a must,
treat yourself, you deserve, so good, wonderful, fantastic, swell, bro, dude,
gnarly, epic, vibes, lowkey, highkey, slaps, bussin, fire (as adjective),
no cap, hits different, chef's kiss

CRITICAL: Do NOT be warm, enthusiastic, or eager. Do NOT sell. Be the cool
person who already knows. Confidence, not excitement.

Write exactly 4 taglines, one per pattern:

PATTERN 1 — FOOD FORWARD: Lead with what they serve. State it as fact.
Add a drink detail or location anchor. End with a deadpan closer if it fits.

PATTERN 2 — NEIGHBORHOOD ANCHOR: Lead with where they are — street name,
micro-location, or neighborhood. Connect with a confident statement that
doesn't explain itself.

PATTERN 3 — VIBE CHECK: Put the reader in the scene. Short sensory
statements. What it feels like to be there, not why it's great.

PATTERN 4 — LOCAL AUTHORITY: Maximum confidence, minimum words. The
shortest tagline. A declaration that doesn't need to justify itself.

Each tagline must be:
- 6 to 14 words maximum (shorter is better)
- Confident and cool, never eager or selling
- Drawing from the word pools above (not freestyling vocabulary)
- Specific to THIS merchant using the data provided
- Built with periods and short beats, not commas and flowing phrases

Return ONLY a JSON array of 4 strings. No commentary. No labels.
---

USER PROMPT
---
Name: {name}
Category: {category}
Neighborhood: {neighborhood}
Street: {street}
Price Level: {price_level}
Outdoor Seating: {outdoor_seating}
Serves Beer: {serves_beer}
Serves Wine: {serves_wine}
Serves Cocktails: {serves_cocktails}
Serves Breakfast: {serves_breakfast}
Serves Brunch: {serves_brunch}
Live Music: {live_music}
Service Style: {service_style}
Popularity: {popularity_tier} ({user_rating_count} reviews)
---
```

**Micro-location rule:** If the map already contains the neighborhood name (e.g., "Echo Park Eats"), Pattern 2 should use the street name ("on Sunset") instead of repeating the neighborhood.

### 3. Auto-Selection

Second lightweight AI call to pick the best of 4:

```
SYSTEM PROMPT
---
You are an editorial quality filter. Pick the single best tagline based on:
1. Confidence — sounds like it already knows, not trying to convince
2. Specificity — could only belong to THIS restaurant
3. Rhythm — reads well out loud, periods land correctly
4. Length — shorter wins if quality is equal

Return ONLY the index (0, 1, 2, or 3). No commentary.
---

USER PROMPT
---
Restaurant: {name} ({category}, {neighborhood})

Options:
0: "{tagline_0}"
1: "{tagline_1}"
2: "{tagline_2}"
3: "{tagline_3}"
---
```

### 4. Banned Word Validator

Post-generation filter. If any tagline contains a banned word, auto-reject it and flag for regeneration:

```typescript
const BANNED_WORDS = [
  'hidden gem', 'must-try', 'elevated', 'curated', 'artisanal',
  'mouthwatering', 'to die for', 'delicious', 'amazing', 'incredible',
  'unique', 'authentic', 'foodie', 'farm-to-table', 'crafted',
  'perfect for', "you'll love", "don't miss", 'a must',
  'treat yourself', 'you deserve', 'so good', 'wonderful', 'fantastic',
  'swell', 'bro', 'dude', 'gnarly', 'epic', 'vibes',
  'lowkey', 'highkey', 'slaps', 'bussin', 'no cap',
  'hits different', "chef's kiss"
];

function validateTagline(tagline: string): boolean {
  const lower = tagline.toLowerCase();
  return !BANNED_WORDS.some(word => lower.includes(word));
}
```

### 5. Ad Unit Assignment

Category-based mapping from Google Places `primaryType` to ad unit style:

```typescript
const CATEGORY_TO_AD_UNIT: Record<string, string> = {
  // Matchbook (B) — casual spots
  'fast_food_restaurant': 'B',
  'pizza_restaurant': 'B',
  'hamburger_restaurant': 'B',
  'sandwich_shop': 'B',
  'bakery': 'B',
  'cafe': 'B',
  'coffee_shop': 'B',
  'ice_cream_shop': 'B',
  'meal_takeaway': 'B',
  'meal_delivery': 'B',

  // Classic Print Ad (A) — elevated dining
  'fine_dining_restaurant': 'A',
  'steak_house': 'A',
  'seafood_restaurant': 'A',
  'french_restaurant': 'A',
  'wine_bar': 'A',
  'cocktail_bar': 'A',

  // Illustrated Stamp (D) — provenance/craft
  'brewery': 'D',
  'winery': 'D',
  'distillery': 'D',
  'bar': 'D',

  // Horizontal Banner (E) — default/everything else
};

function getAdUnitType(primaryType: string): string {
  return CATEGORY_TO_AD_UNIT[primaryType] || 'E';
}
```

### 6. Data Model

Add these fields to the merchant/place schema:

```prisma
// Tagline fields
tagline              String?
tagline_candidates   String[]
tagline_pattern      String?    // "food" | "neighborhood" | "vibe" | "authority"
tagline_generated    DateTime?
tagline_signals      Json?      // Snapshot of merchant signals at generation time

// Ad unit fields
ad_unit_type         String?    // "A" | "B" | "D" | "E"
ad_unit_override     Boolean    @default(false)

// Editorial pull quote fields (content provided separately — just build the schema)
pull_quote           String?
pull_quote_source    String?    // "The Infatuation", "Eater LA", etc.
pull_quote_author    String?
pull_quote_url       String?
pull_quote_type      String?    // "editorial" | "owner" | "self"
```

### 7. Generation Pipeline

```
[Restaurant added to map]
  → Is it a restaurant type? (check primaryType)
  → Yes: Assign ad_unit_type via CATEGORY_MAP
  → Gather merchant signals from Google Places
  → Derive popularityTier, vibe, timeOfDay
  → Call tagline generator (Claude Haiku — cheap, fast)
  → Validate all 4 against banned words
  → Call auto-selector on valid candidates
  → Store tagline + candidates + signals snapshot + ad_unit_type
  → Render on merchant page
```

**Trigger:** On save when a restaurant is added (not on drag)
**Async:** Map saves immediately, tagline populates when ready
**Retry:** If generation fails, retry once. If still fails, use fallback: `"A fine establishment. Saiko approved."`
**Model:** Claude Haiku (cheapest capable model — this is short-form creative, doesn't need Opus)
**Batch:** If CSV import adds 50 restaurants, parallelize with concurrency of 10

### 8. What NOT to Build Yet

- **Ad unit rendering / UI** — visual designs are coming in a separate handoff
- **Pull quote sourcing** — the schema fields are above but the search/scraping pipeline isn't specced yet
- **Map creator tagline editing UI** — future feature
- **"Regenerate taglines" button** — future feature
- **Non-restaurant merchants** — restaurants only for now

---

## Quality Bar

Here's what good v1.1 output looks like (these are the approved prototypes):

| Restaurant | Tagline |
|-----------|---------|
| Guisados | If you know Sunset, you already know Guisados. |
| Sticky Rice | The Thai spot. Ask around. |
| Canyon Coffee | Good coffee. Nice light. Don't be in a hurry. |
| Lowboy | Posted up at the bar. Burger's in. Everything's fine. |
| Bacetti Trattoria | They take their time here. So should you. |
| DADA Echo Park | We'd tell you more, but that's not really how this works. |

If the generated output sounds warmer, friendlier, or more enthusiastic than these examples, the tone is wrong.
