# Saiko Maps — Session Briefing
## Pull Quote Design + Cursor Handoff Prep
**For use in:** Fresh Claude chat, morning of February 6, 2026

---

## What You're Walking Into

We've been building the creative pipeline for Saiko Maps merchant pages — the system that generates copy and assigns visual ad units to restaurants on a map. Across three sessions we completed the back-end logic, vocabulary, and editorial research. What's left before handing to Cursor is **designing how editorial pull quotes render in the existing ad units.**

---

## What's Done

### 1. Creative Pipeline Spec ✅
Full spec for AI tagline generation + ad unit assignment. Covers:
- Tagline Engine (generates 4 candidates per restaurant, auto-selects best)
- Ad Unit Selector (assigns one of 4 vintage ad styles based on restaurant category)
- Generation flow (trigger → assign unit → generate taglines → select → store → render)
- Data model additions (tagline, tagline_candidates, ad_unit_type)

**File:** `saiko-creative-pipeline-spec.md`
**Note:** The voice definition in this file is v1 (warm/enthusiastic) — it was superseded by v1.1.

### 2. Voice Engine v1.1 ✅
The actual vocabulary system Cursor will implement. Key elements:
- **Voice:** Cool, confident, deadpan. "The person who already knows." Not enthusiastic.
- **Word Pools:** Praise Words, Place Words, Action Words, Deadpan Closers, Neighborhood Flavor, Food & Drink, Banned Words
- **4 Phrase Patterns:** Food Forward, Neighborhood Anchor, Vibe Check, Local Authority
- **System + User Prompts:** Ready to drop into code
- **Merchant Signals:** Maps Google Places API fields to word selection
- **Selection Criteria:** Confidence > Specificity > Rhythm > Length

**File:** `saiko-voice-engine-v1.1.md` (supersedes v1)

### 3. Prototype Output ✅
All 24 taglines (4 per restaurant × 6 restaurants) written in v1.1 tone, with picks and reasoning:
- Guisados → "If you know Sunset, you already know Guisados."
- Sticky Rice → "The Thai spot. Ask around."
- Canyon Coffee → "Good coffee. Nice light. Don't be in a hurry."
- Lowboy → "Posted up at the bar. Burger's in. Everything's fine."
- Bacetti → "They take their time here. So should you."
- DADA → "We'd tell you more, but that's not really how this works."

**File:** `saiko-voice-engine-v1.1-revised-prototype.md`

### 4. Editorial Pull Quotes ✅
Researched real editorial coverage for all 6 prototype restaurants. Found quotable lines from The Infatuation, Eater LA, Resy, Dwell, Variety, Wallpaper*. Includes:
- Recommended quote per restaurant with source + URL
- Backup quotes
- Data model addition (pull_quote, pull_quote_source, pull_quote_author, pull_quote_url, pull_quote_type)
- Quote type taxonomy: editorial / owner / self
- When to show pull quote vs. AI tagline vs. both
- Source priority ranking (Infatuation > Eater > prestige pubs > restaurant's own site)

**File:** `saiko-editorial-pull-quotes.md`

### 5. Voice Engine Implementation (Cursor — in progress) ⏳
Cursor has read the v1 spec and is ready to implement. We've prepared a prompt (separate file) that gives it v1.1 direction and tells it to build the tagline generator, ad unit selector, and data model.

**File:** `saiko-cursor-voice-engine-prompt.md`

---

## What Needs Design (This Session's Job)

### Pull Quote Visual Treatment

The editorial pull quotes need a visual design before Cursor can build them. Specifically:

**1. Pull quote inside an ad unit**
How does a real editorial quote (with attribution line and source link) render inside the four approved ad unit styles?
- Classic Print Ad (A)
- Matchbook (B)
- Illustrated Stamp (D)
- Horizontal Banner (E)

Does the quote replace the AI tagline, or sit alongside it?

**2. Attribution line styling**
The line that says `— The Infatuation →` (or similar). Typography, color, link behavior.

**3. "Featured in" badge treatment**
For restaurants like Guisados that have press credentials (GQ, CNN, Bon Appétit) but no single quotable line — how does a badge/logo row look?

**4. Quote type variations**
Three types: editorial (from a publication), owner (from the owner quoted in a publication), self (from the restaurant's own site). Do they render differently?

**5. Fallback hierarchy**
When a restaurant has both a pull quote AND an AI tagline, what shows where?

### Design Context

**Existing approved ad unit designs live in:** `quiet-cards-and-ad-units.html` (from a previous session — already in the `cursor-handoff/mockups/` folder on Bobby's machine)

**Template palette:** Field Notes theme — parchment, khaki, charcoal, leather
**Headline font:** Playfair Display (italic for titles)
**Body font:** System sans-serif stack
**Accent color:** Coral (#E07A5F)

---

## Reference Files (All in `/mnt/user-data/outputs/`)

| File | What It Is | Status |
|------|-----------|--------|
| `saiko-creative-pipeline-spec.md` | Full pipeline architecture | ✅ Done (voice section = v1, superseded) |
| `saiko-voice-engine-v1.1.md` | Vocabulary system + phrase generator | ✅ Done |
| `saiko-voice-engine-v1.1-revised-prototype.md` | 24 taglines, 6 restaurants | ✅ Done |
| `saiko-editorial-pull-quotes.md` | Real editorial quotes + data model | ✅ Done |
| `saiko-voice-engine-v1.md` | Original voice engine (superseded) | Archive |
| `saiko-voice-engine-prototype-output.md` | Original prototype (superseded) | Archive |

### Files on Bobby's Machine (from earlier sessions)
| File | Location |
|------|----------|
| `quiet-cards-and-ad-units.html` | `~/saiko-maps/cursor-handoff/mockups/` |
| `HANDOFF.md` | `~/saiko-maps/cursor-handoff/` |
| `design-tokens.html` | `~/saiko-maps/cursor-handoff/mockups/` |
| `title-card.html` | `~/saiko-maps/cursor-handoff/mockups/` |
| `merchant-page.html` | `~/saiko-maps/cursor-handoff/mockups/` |
| `headers-footers.html` | `~/saiko-maps/cursor-handoff/mockups/` |
| `sharing-images.html` | `~/saiko-maps/cursor-handoff/mockups/` |

---

## Suggested Session Flow

1. Upload the 6 files listed above from `/mnt/user-data/outputs/` (or reference them in the prompt)
2. Ask Claude to design the pull quote treatment for all 4 ad unit styles
3. Review and approve the HTML mockups
4. Update the Cursor handoff with the new mockups
5. Done — everything goes to Cursor
