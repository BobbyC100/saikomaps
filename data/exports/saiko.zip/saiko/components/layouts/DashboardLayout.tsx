import Link from 'next/link';
export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-bg-primary">
      <nav className="bg-bg-secondary border-b border-border-light sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/dashboard" className="text-2xl font-serif font-semibold text-accent-primary">
              Chartroom
            </Link>
            <div className="flex items-center gap-6">
              <Link href="/dashboard" className="text-text-secondary hover:text-text-primary">Dashboard</Link>
              <Link href="/import" className="text-text-secondary hover:text-text-primary">Import</Link>
              <Link href="/lists" className="text-text-secondary hover:text-text-primary">My Lists</Link>
              <Link href="/settings" className="text-text-secondary hover:text-text-primary">Settings</Link>
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-6 py-12">
        {children}
      </main>
    </div>
  );
}
