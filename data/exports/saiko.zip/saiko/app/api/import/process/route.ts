/**
 * API Route: Process Import
 * POST /api/import/process
 * Create list and enrich locations with Google Places API
 */

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { processImportSchema } from '@/lib/validations'
import { searchPlace, getPlaceDetails } from '@/lib/google-places'
import { generateSlug } from '@/lib/utils'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate input
    const validation = processImportSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json(
        { error: 'Invalid input', details: validation.error.errors },
        { status: 400 }
      )
    }

    const { listTitle, templateType, locations } = validation.data

    // TODO: Get user ID from session (once auth is set up)
    // For now, we'll need to create a test user or skip this
    const userId = body.userId // Temporary - will come from auth session

    if (!userId) {
      return NextResponse.json(
        { error: 'User authentication required' },
        { status: 401 }
      )
    }

    // Create the list
    const slug = generateSlug(listTitle)
    const list = await db.list.create({
      data: {
        userId,
        title: listTitle,
        slug: `${slug}-${Date.now()}`, // Add timestamp to ensure uniqueness
        templateType,
        accessLevel: 'private', // Default to private
      },
    })

    // Create import job
    const importJob = await db.importJob.create({
      data: {
        userId,
        listId: list.id,
        status: 'processing',
        totalLocations: locations.length,
        processedLocations: 0,
        failedLocations: 0,
      },
    })

    // Process locations asynchronously
    // In production, this should be a background job (e.g., with Bull/Redis)
    processLocationsAsync(importJob.id, list.id, locations)

    return NextResponse.json({
      success: true,
      data: {
        listId: list.id,
        importJobId: importJob.id,
        slug: list.slug,
      },
    })
  } catch (error) {
    console.error('Error processing import:', error)
    return NextResponse.json(
      { 
        error: 'Failed to process import',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}

// ============================================
// ASYNC PROCESSING
// ============================================

async function processLocationsAsync(
  importJobId: string,
  listId: string,
  locations: Array<{ name: string; address?: string; comment?: string }>
) {
  const errorLog: any[] = []
  let processed = 0
  let failed = 0

  for (const location of locations) {
    try {
      // Search for place
      const searchQuery = location.address 
        ? `${location.name}, ${location.address}`
        : location.name

      const searchResults = await searchPlace(searchQuery, { maxResults: 1 })
      
      if (searchResults.length === 0) {
        // No place found, create location without enrichment
        await db.location.create({
          data: {
            listId,
            name: location.name,
            address: location.address,
            userNote: location.comment,
            orderIndex: processed,
          },
        })
        
        errorLog.push({
          location: location.name,
          error: 'Place not found in Google Places',
        })
        failed++
      } else {
        // Get place details
        const placeId = searchResults[0].placeId
        const placeDetails = await getPlaceDetails(placeId)

        if (placeDetails) {
          // Create enriched location
          await db.location.create({
            data: {
              listId,
              googlePlaceId: placeId,
              name: placeDetails.name,
              address: placeDetails.address,
              latitude: placeDetails.latitude,
              longitude: placeDetails.longitude,
              phone: placeDetails.phone,
              website: placeDetails.website,
              hours: placeDetails.hours,
              description: placeDetails.description,
              googlePhotos: placeDetails.photos,
              userNote: location.comment,
              placesDataCachedAt: new Date(),
              orderIndex: processed,
            },
          })
        } else {
          throw new Error('Failed to fetch place details')
        }
      }

      processed++

      // Update progress
      await db.importJob.update({
        where: { id: importJobId },
        data: {
          processedLocations: processed,
          failedLocations: failed,
        },
      })

      // Rate limiting: wait 100ms between requests
      await new Promise(resolve => setTimeout(resolve, 100))
    } catch (error) {
      console.error(`Error processing location ${location.name}:`, error)
      
      errorLog.push({
        location: location.name,
        error: error instanceof Error ? error.message : 'Unknown error',
      })
      
      failed++
      
      // Still create a basic location entry
      try {
        await db.location.create({
          data: {
            listId,
            name: location.name,
            address: location.address,
            userNote: location.comment,
            orderIndex: processed,
          },
        })
      } catch (dbError) {
        console.error('Failed to create fallback location:', dbError)
      }
    }
  }

  // Mark import job as complete
  await db.importJob.update({
    where: { id: importJobId },
    data: {
      status: failed === locations.length ? 'failed' : 'completed',
      processedLocations: processed,
      failedLocations: failed,
      completedAt: new Date(),
      errorLog: errorLog.length > 0 ? errorLog : null,
    },
  })
}

