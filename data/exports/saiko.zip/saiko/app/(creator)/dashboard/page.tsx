'use client';

import { useState } from 'react';
import DashboardLayout from '@/components/layouts/DashboardLayout';
import type { List, DashboardStats } from '@/types/dashboard';

const mockStats: DashboardStats = {
  totalGuides: 12,
  totalLocations: 248,
  totalViews: 1847,
  publishedGuides: 8,
  draftGuides: 4,
};

const mockLists: List[] = [
  {
    id: '1',
    title: 'Tokyo Coffee Guide',
    slug: 'tokyo-coffee-guide',
    description: 'The best specialty coffee shops across Tokyo',
    isPublished: true,
    locationCount: 24,
    viewCount: 342,
    template: 'MONOCLE',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-03-20'),
  },
];

export default function DashboardPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  return (
    <DashboardLayout>
      <div className="space-y-12">
        <h1 className="text-5xl font-serif font-semibold text-text-primary">Dashboard</h1>
        <div className="grid grid-cols-4 gap-6">
          <div className="bg-bg-secondary border border-border-light rounded-lg p-6">
            <div className="text-sm font-medium text-text-tertiary uppercase tracking-wider mb-2">Total Guides</div>
            <div className="text-4xl font-serif font-semibold text-text-primary">{mockStats.totalGuides}</div>
          </div>
          <div className="bg-bg-secondary border border-border-light rounded-lg p-6">
            <div className="text-sm font-medium text-text-tertiary uppercase tracking-wider mb-2">Locations</div>
            <div className="text-4xl font-serif font-semibold text-text-primary">{mockStats.totalLocations}</div>
          </div>
          <div className="bg-bg-secondary border border-border-light rounded-lg p-6">
            <div className="text-sm font-medium text-text-tertiary uppercase tracking-wider mb-2">Total Views</div>
            <div className="text-4xl font-serif font-semibold text-text-primary">{mockStats.totalViews}</div>
          </div>
          <div className="bg-bg-secondary border border-border-light rounded-lg p-6">
            <div className="text-sm font-medium text-text-tertiary uppercase tracking-wider mb-2">Status</div>
            <div className="text-4xl font-serif font-semibold text-success">{mockStats.publishedGuides} / {mockStats.totalGuides}</div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
