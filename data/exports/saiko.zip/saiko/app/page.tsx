'use client'

import Link from 'next/link'
import Image from 'next/image'

export default function Home() {
  return (
    <div className="min-h-screen bg-bg-primary">
      <div className="max-w-6xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <Image
              src="/saiko-logo.png"
              alt="Saiko Maps"
              width={120}
              height={120}
            />
          </div>
          <h1 className="text-6xl font-semibold text-accent-primary mb-4">
            Saiko Maps
          </h1>
          <p className="text-xl text-text-secondary">
            Create cool, personal maps — fast
          </p>
        </div>

        <div className="flex gap-4 justify-center">
          <Link
            href="/dashboard"
            className="px-8 py-4 bg-accent-primary text-white rounded-lg hover:opacity-90 transition-opacity font-medium text-lg"
          >
            Go to Dashboard
          </Link>
          <Link
            href="/import"
            className="px-8 py-4 border-2 border-accent-primary text-accent-primary rounded-lg hover:bg-accent-primary hover:text-white transition-colors font-medium text-lg"
          >
            Create a Map
          </Link>
        </div>
      </div>
    </div>
  )
}
