# Saiko Maps

Create cool, personal maps — fast.

A lightweight creative tool for making shareable maps with curated templates that are more visual, playful, and expressive than traditional mapping tools.

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Environment Setup

Create a `.env` file:

```
DATABASE_URL="postgresql://..."
GOOGLE_PLACES_API_KEY="your_api_key"
NEXTAUTH_SECRET="your_secret"
NEXTAUTH_URL="http://localhost:3000"
```

Then:

```bash
npm run db:generate
npm run db:push
```

## Tech Stack

- Next.js 16 + TypeScript
- Tailwind CSS v4
- PostgreSQL + Prisma
- Google Places API

## Scripts

```bash
npm run dev          # Development
npm run build        # Production build
npm run db:studio    # Database GUI
```

---

**saikomaps.com**
